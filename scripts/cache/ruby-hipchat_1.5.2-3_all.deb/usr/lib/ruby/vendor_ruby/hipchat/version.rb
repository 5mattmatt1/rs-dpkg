module HipChat
  VERSION = '1.5.2'
end
