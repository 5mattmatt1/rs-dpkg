#warning "the .pxi files in the cysignals package are deprecated and kept for backwards compatibility only; use regular cimports instead"
