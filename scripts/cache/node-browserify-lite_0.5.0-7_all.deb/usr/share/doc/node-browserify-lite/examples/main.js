var printer = require('./printer');

printer.print('1');
printer.print('2');
printer.print('3');
printer.print('4');