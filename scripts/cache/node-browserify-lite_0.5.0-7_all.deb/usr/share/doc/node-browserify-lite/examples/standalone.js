(function(modules, cache, entry) {
  window.example = req(entry);
  function req(name) {
    if (cache[name]) return cache[name].exports;
    var m = cache[name] = {exports: {}};
    modules[name][0].call(m.exports, modRequire, m, m.exports, window);
    return m.exports;
    function modRequire(alias) {
      var id = modules[name][1][alias];
      if (!id) throw new Error("Cannot find module " + alias);
      return req(id);
    }
  }
})({0: [function(require,module,exports,global){
var printer = require('./printer');

printer.print('1');
printer.print('2');
printer.print('3');
printer.print('4');
}, {"./printer":1}],1: [function(require,module,exports,global){
var i = 1;
var max = 30;

module.exports = {
  print: function () {
    for (i -= 1; i++ < max; ) {
      console.log(i);
    }
    max *= 1.1;
  }
};
}, {}],}, {}, 0);
