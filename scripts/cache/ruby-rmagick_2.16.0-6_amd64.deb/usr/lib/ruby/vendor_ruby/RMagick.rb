puts "W: `require 'RMagick'` is deprecated, please change to `require 'rmagick'`"
require 'rmagick'
