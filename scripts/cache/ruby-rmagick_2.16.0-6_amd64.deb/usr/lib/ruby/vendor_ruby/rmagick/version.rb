module Magick
  VERSION = '2.16.0'
  MIN_RUBY_VERSION = '1.8.5'
  MIN_IM_VERSION = '6.4.9'
  MIN_WAND_VERSION = '6.9.0'
end
