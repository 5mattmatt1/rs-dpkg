RMAGICK_BYPASS_VERSION_TEST = true
require 'rmagick_internal.rb'
