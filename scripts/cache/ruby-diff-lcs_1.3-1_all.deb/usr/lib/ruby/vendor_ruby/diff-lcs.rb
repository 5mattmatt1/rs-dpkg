# -*- ruby encoding: utf-8 -*-

require 'diff/lcs'
